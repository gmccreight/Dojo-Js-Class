var Constants = {
   EMAIL: "hackerfair.craigslist_job_email",
   BODY_TEMPLATE: "hackerfair.craigslist_job_body"
};
